import pandas as pd
import matplotlib.pyplot as plt

# Load the financial report data
financial_report = pd.read_csv('Financial Report.csv')

# Extract relevant fields for the line chart
earnings_data = financial_report[['Receipt Date', 'Amount']]

# Convert 'Receipt Date' to datetime format
earnings_data['Receipt Date'] = pd.to_datetime(earnings_data['Receipt Date'])

# Group by 'Receipt Date' and sum the 'Amount' for each date
earnings_summary = earnings_data.groupby('Receipt Date')['Amount'].sum().reset_index()

# Plotting the line chart
plt.figure(figsize=(12, 6))
plt.plot(earnings_summary['Receipt Date'], earnings_summary['Amount'], marker='o', linestyle='-', color='b')
plt.title('Earnings Over Time')
plt.xlabel('Receipt Date')
plt.ylabel('Amount')
plt.grid(True)
plt.xticks(rotation=45)
plt.tight_layout()

plt.show()
